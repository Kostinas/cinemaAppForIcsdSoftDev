package com.cinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CinemaManagerApplication.class, args);
    }
}
