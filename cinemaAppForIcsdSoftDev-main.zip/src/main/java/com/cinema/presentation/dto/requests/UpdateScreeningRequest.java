package com.cinema.presentation.dto.requests;

public record UpdateScreeningRequest(String title, String genre, String description) {
}
