package com.cinema.presentation.dto.responses;

public record UserResponse(
        Long id,
        String userName,
        String fullName,
        String role,
        boolean active
) {
}
