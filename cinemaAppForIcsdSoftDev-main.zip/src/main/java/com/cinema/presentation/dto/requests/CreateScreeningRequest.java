package com.cinema.presentation.dto.requests;

public record CreateScreeningRequest(String title, String genre, String description) {
}
