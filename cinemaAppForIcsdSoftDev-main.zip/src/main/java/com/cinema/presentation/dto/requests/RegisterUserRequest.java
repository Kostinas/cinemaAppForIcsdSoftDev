package com.cinema.presentation.dto.requests;

public record RegisterUserRequest(String username, String password, String fullName) {
}
