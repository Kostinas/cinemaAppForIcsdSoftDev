package com.cinema.presentation.dto.responses;

public record TokenInfoResponse(Long userId, String role) {
}
