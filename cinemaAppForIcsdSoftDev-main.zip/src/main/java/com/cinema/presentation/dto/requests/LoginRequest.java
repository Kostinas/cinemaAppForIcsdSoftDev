package com.cinema.presentation.dto.requests;

public record LoginRequest(String username, String password) {
}
