package com.cinema.presentation.controller;

import com.cinema.application.users.ChangePasswordUseCase;
import com.cinema.application.users.DeactivateUserUseCase;
import com.cinema.application.users.DeleteUserUseCase;
import com.cinema.application.users.RegisterUserUseCase;
import com.cinema.application.users.ActivateUserUseCase;
import com.cinema.domain.entity.value.UserId;
import com.cinema.domain.port.UserRepository;
import com.cinema.presentation.dto.responses.UserResponse;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.cinema.presentation.dto.requests.RegisterUserRequest;
import com.cinema.presentation.dto.requests.ChangePasswordRequest;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final RegisterUserUseCase registerUser;
    private final ChangePasswordUseCase changePassword;
    private final DeactivateUserUseCase deactivateUser;
    private final DeleteUserUseCase deleteUser;
    private final ActivateUserUseCase activateUser;
    private final UserRepository userRepository;

    public UserController(
            RegisterUserUseCase registerUser,
            ChangePasswordUseCase changePassword,
            DeactivateUserUseCase deactivateUser,
            DeleteUserUseCase deleteUser,
            ActivateUserUseCase activateUser,
            UserRepository userRepository
    ){
        this.registerUser = registerUser;
        this.changePassword = changePassword;
        this.deactivateUser = deactivateUser;
        this.deleteUser = deleteUser;
        this.activateUser = activateUser;
        this.userRepository = userRepository;
    }


    @PostMapping
    public ResponseEntity<Void> register(@RequestBody RegisterUserRequest request) {
        registerUser.register(
                request.username(),
                request.password(),
                request.fullName()
        );
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/password")
    public ResponseEntity<Void> changePassword(@PathVariable Long id, @RequestBody ChangePasswordRequest request) {

        changePassword.changePassword(
                new UserId(id),
                request.oldPassword(),
                request.newPassword()
        );
        return ResponseEntity.ok().build();
    }

        @PutMapping("/{id}/deactivate")
    public ResponseEntity<Void> deactivate(
            @PathVariable Long id,
            jakarta.servlet.http.HttpServletRequest request
    ) {
        ensureAdmin(request);

        deactivateUser.deactivate(new UserId(id));
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/activate")
    public ResponseEntity<Void> activate(
            @PathVariable Long id,
            jakarta.servlet.http.HttpServletRequest request
    ) {
        ensureAdmin(request);

        activateUser.activate(new UserId(id));
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @PathVariable Long id,
            jakarta.servlet.http.HttpServletRequest request
    ) {
        ensureAdmin(request);

        deleteUser.delete(new UserId(id));
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<UserResponse>> list(
            jakarta.servlet.http.HttpServletRequest request
    ) {
        ensureAdmin(request);

        var users = userRepository.findAll();
        var dto = users.stream()
                .map(u -> new UserResponse(
                        u.id().value(),
                        u.username().value(),
                        u.fullName(),
                        u.baseRole().name(),
                        u.isActive()
                ))
                .toList();

        return ResponseEntity.ok(dto);
    }

    // --- μόνο ADMIN μπορεί να κάνει user management ---
    private void ensureAdmin(jakarta.servlet.http.HttpServletRequest request) {
        com.cinema.domain.enums.BaseRole role =
                (com.cinema.domain.enums.BaseRole) request.getAttribute("role");

        if (role == null || role != com.cinema.domain.enums.BaseRole.ADMIN) {
            throw new com.cinema.domain.Exceptions.AuthorizationException(
                    "Only ADMIN can manage users"
            );
        }
    }
}
