package com.cinema.domain.enums;

public enum BaseRole {
    VISITOR,
    USER,
    PROGRAMMER,
    STAFF,
    SUBMITTER,
    ADMIN;
}
