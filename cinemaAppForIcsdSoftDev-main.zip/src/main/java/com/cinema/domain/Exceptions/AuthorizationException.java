package com.cinema.domain.Exceptions;

public class AuthorizationException extends DomainException{

    public AuthorizationException(String message){
        super(message);
    }
}
