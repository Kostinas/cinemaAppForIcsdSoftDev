package com.cinema.infrastructure.config;

import com.cinema.domain.entity.User;
import com.cinema.domain.entity.value.HashedPassword;
import com.cinema.domain.entity.value.UserId;
import com.cinema.domain.entity.value.Username;
import com.cinema.domain.enums.BaseRole;
import com.cinema.domain.policy.PasswordPolicy;
import com.cinema.domain.port.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.UUID;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner seedUsers(UserRepository userRepository,
                                       PasswordPolicy passwordPolicy) {
        return args -> {
            System.out.println(">>> DataInitializer: seeding users...");

            seedUserIfMissing(
                    userRepository,
                    passwordPolicy,
                    "admin01",
                    "Default Admin",
                    "F3$CinemaHub",    // ισχυρό password, χωρίς "admin"
                    BaseRole.ADMIN
            );

            seedUserIfMissing(
                    userRepository,
                    passwordPolicy,
                    "prog01",
                    "Programmer One",
                    "R8#FestivalX",    // ισχυρό password, χωρίς "prog"
                    BaseRole.PROGRAMMER
            );

            seedUserIfMissing(
                    userRepository,
                    passwordPolicy,
                    "staff01",
                    "Staff Member One",
                    "T6!CrewShift",    // ισχυρό password, χωρίς "staff"
                    BaseRole.STAFF
            );

            seedUserIfMissing(
                    userRepository,
                    passwordPolicy,
                    "submit01",
                    "Submitter One",
                    "Q5@TicketBox",    // ισχυρό password, χωρίς "submit"
                    BaseRole.SUBMITTER
            );
        };
    }

    private void seedUserIfMissing(UserRepository userRepository,
                                   PasswordPolicy passwordPolicy,
                                   String rawUsername,
                                   String fullName,
                                   String rawPassword,
                                   BaseRole role) {

        boolean exists = userRepository.findAll().stream()
                .anyMatch(u -> u.username() != null
                        && u.username().value().equals(rawUsername));

        if (exists) {
            System.out.println(">>> DataInitializer: user '" + rawUsername + "' already exists, skipping.");
            return;
        }

        try {
            Username username = new Username(rawUsername);

            // εδώ εφαρμόζουμε ΟΛΟΥΣ τους κανόνες password σου
            passwordPolicy.validate(rawPassword, username, fullName).ensureValid();

            HashedPassword password = HashedPassword.fromRaw(rawPassword);

            long randomId = Math.abs(UUID.randomUUID().getLeastSignificantBits());

            User user = new User(
                    new UserId(randomId),
                    username,
                    password,
                    fullName,
                    role,
                    true,   // active
                    0       // version
            );

            userRepository.Save(user);
            System.out.println(">>> DataInitializer: created " + role + " user '" + rawUsername + "'");

        } catch (Exception e) {
            System.out.println(">>> DataInitializer: could not create user '" + rawUsername + "': " + e.getMessage());
        }
    }
}
