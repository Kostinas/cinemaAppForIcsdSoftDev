export default function ForbiddenPage() {
  return (
    <div>
      <h1>403 – Forbidden</h1>
      <p>You do not have access to this page.</p>
    </div>
  );
}
